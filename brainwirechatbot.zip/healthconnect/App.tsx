
import React, { useState, useEffect, useRef } from 'react';
import type { Chat } from '@google/genai';
import { initializeChat, sendMessageToAI } from './services/geminiService';
import { Message, Sender } from './types';
import ChatWindow from './components/ChatWindow';
import InputBar from './components/InputBar';

const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const chatRef = useRef<Chat | null>(null);

  useEffect(() => {
    try {
      chatRef.current = initializeChat();
      setMessages([
        {
          id: 'initial',
          text: "Hello! I'm HealthConnect. I can provide general information on health topics. How can I help you today? Please remember, I am not a substitute for a real doctor.",
          sender: Sender.Bot,
        },
      ]);
    } catch (e: any) {
      setError(e.message);
      console.error(e);
    }
  }, []);

  const handleSendMessage = async (text: string) => {
    if (!chatRef.current) {
      setError("Chat is not initialized. Please refresh the page.");
      return;
    }

    const userMessage: Message = {
      id: Date.now().toString(),
      text,
      sender: Sender.User,
    };
    setMessages((prevMessages) => [...prevMessages, userMessage]);
    setIsLoading(true);
    setError(null);

    try {
      const botResponseText = await sendMessageToAI(chatRef.current, text);
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: botResponseText,
        sender: Sender.Bot,
      };
      setMessages((prevMessages) => [...prevMessages, botMessage]);
    } catch (e: any) {
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: "Sorry, I encountered an error. Please try again.",
        sender: Sender.Bot,
      };
      setMessages((prevMessages) => [...prevMessages, errorMessage]);
      setError("Failed to get a response from the AI.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-screen max-w-4xl mx-auto bg-gray-50 shadow-lg">
      <header className="p-4 bg-white border-b border-gray-200 shadow-sm">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-blue-500 rounded-full">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
            </svg>
          </div>
          <h1 className="text-xl font-bold text-gray-800">HealthConnect</h1>
        </div>
      </header>

      {error && (
        <div className="p-4 bg-red-100 text-red-700 text-center text-sm">
          <strong>Error:</strong> {error}
        </div>
      )}

      <ChatWindow messages={messages} isLoading={isLoading} />
      <InputBar onSendMessage={handleSendMessage} isLoading={isLoading} />
    </div>
  );
};

export default App;
