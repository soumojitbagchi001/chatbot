
import React from 'react';
import { Message, Sender } from '../types';

interface MessageProps {
  message: Message;
}

const EMERGENCY_MESSAGE_PREFIX = "**If you are experiencing a medical emergency";

const MessageComponent: React.FC<MessageProps> = ({ message }) => {
  const isUser = message.sender === Sender.User;
  const isEmergency = message.text.startsWith(EMERGENCY_MESSAGE_PREFIX);

  const messageParts = message.text.split('---');
  const mainText = messageParts[0];
  const disclaimerText = messageParts.length > 1 ? messageParts[1] : null;

  const baseClasses = 'px-4 py-3 rounded-2xl max-w-lg lg:max-w-xl xl:max-w-2xl break-words';
  
  const userClasses = `bg-blue-500 text-white self-end ${baseClasses}`;
  const botClasses = `bg-white text-gray-800 self-start shadow-sm ${baseClasses}`;
  const emergencyClasses = `bg-red-100 border border-red-500 text-red-800 self-start ${baseClasses}`;

  const messageClass = isUser ? userClasses : isEmergency ? emergencyClasses : botClasses;
  
  const formatText = (text: string) => {
    // Basic markdown for bolding
    const formattedText = text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    return { __html: formattedText };
  };

  return (
    <div className={`flex flex-col mb-4 ${isUser ? 'items-end' : 'items-start'}`}>
      <div className={messageClass}>
        <p className="text-sm" dangerouslySetInnerHTML={formatText(mainText.trim())}></p>
        {disclaimerText && (
          <>
            <hr className="my-2 border-gray-200" />
            <p className="text-xs italic text-gray-500">{disclaimerText.trim()}</p>
          </>
        )}
      </div>
    </div>
  );
};

export default MessageComponent;
